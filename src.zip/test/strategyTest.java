
public class strategyTest {
}
