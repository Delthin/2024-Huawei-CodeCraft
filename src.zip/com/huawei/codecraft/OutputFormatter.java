package com.huawei.codecraft;

/**
 * OutputFormatter
 * 负责格式化输出数据,生成控制指令字符串。
 * formatMoveRobot(int robotId, int direction)方法:格式化机器人移动指令
 * formatPickUpGoods(int robotId)方法:格式化捡起货物指令
 * formatPutDownGoods(int robotId)方法:格式化放下货物指令
 * formatMoveBoat(int boatId, int berthId)方法:格式化移动船只指令
 * formatSailBoat(int boatId)方法:格式化船只运输指令
 */
public class OutputFormatter {
    public static String formatMoveRobot(int robotId, int direction) {
        return null;
    }

    public static String formatPickUpGoods(int robotId) {
        return null;
    }

    public static String formatPutDownGoods(int robotId) {
        return null;
    }

    public static String formatMoveBoat(int shipId, int berthId) {
        return null;
    }

    public static String formatSailBoat(int BoatId) {
        return null;
    }
}
